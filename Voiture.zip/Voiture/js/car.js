"use strict";

function Car(positionY)
{
    this.trackFinished = false;
    this.distanceRemaining = 1000;

    this.position = 
    {
    	x: 0,
    	y: positionY
    };

    this.speed = 1 +  (Math.random() * 100 |0);
    this.turnToFinish = 0;
}

Car.prototype.Accelerate = function()
{
    this.distanceRemaining -= this.speed;
    this.position.x += this.speed;
    this.turnToFinish++;
}

Car.prototype.Draw = function()
{
	game.context.drawImage(game.car, 0, 0, game.car.width / 3, game.car.height / 6, this.position.x, this.position.y, 55, 50);
}