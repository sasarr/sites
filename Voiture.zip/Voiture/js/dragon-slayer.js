/*
document.getElementById("canvas").onmousemove = function(info)
{
    game.context.clearRect(0,0, game.canvas.width, game.canvas.height);

    game.drawTrack();


    var x = info.pageX - this.offsetLeft;
    var y = info.pageY - this.offsetTop;
    game.context.drawImage(game.car, 0, 0, game.car.width / 3, game.car.height / 6, x - ( 55 * 0.5), y - (50 * 0.5), 55, 50);
}

*/