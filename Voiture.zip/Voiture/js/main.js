"use strict";

var game = null;

window.addEventListener("DOMContentLoaded", function()
{
	game = new Game();
	game.Initialize( (1 + Math.random() * 14) |0 );
	setInterval(game.Start, 1000 / 24);
	
});