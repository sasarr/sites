"use strict";

function Game()
{
    this.track = [];
    this.leaderboard = [];
    this.globalTurn = 0;
    this.canvas = document.getElementById("canvas"); 
}

Game.prototype.Initialize = function( numberOfParticipant ) // logique de jeu 
{
    for(var i = 0; i < numberOfParticipant; i++)
    {
        game.track.push( new Car( 10 + i * 55 ) );
    }


	this.context = this.canvas.getContext("2d");

	this.car = new Image();
	this.car.src = "images/voiture.png";

	this.car.onload = function()
	{
	    game.drawTrack();
	    game.drawCars();
	};
};

Game.prototype.Start = function() // logique de jeu 
{
    if(game.leaderboard.length == game.track.length)
    {
    	return;
    }

    game.globalTurn++;
    var randomIndex = Math.floor(Math.random() * game.track.length);
    var randomCar = game.track[randomIndex];

    if(randomCar.trackFinished == false )
    {
        randomCar.Accelerate();

        game.drawTrack();
        game.drawCars();  
    }
    else 
    {
        return;
    }
    
    console.log("la voiture " + randomIndex + " Accellere de " + randomCar.speed + " il lui reste " + randomCar.distanceRemaining + " pixels a parcourir" );
    

    if(randomCar.distanceRemaining < 0)
    {
        console.log("et elle depasse la ligne d'arriv�");
        //this.track.splice(randomIndex, 1);
        game.leaderboard.push(randomIndex);
        randomCar.trackFinished = true;
    }

    console.log("-----------------------------------------------------------------------");
    

    console.log("le classement finale est " + game.leaderboard);
}

//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------
// mes methodes de dessin

Game.prototype.drawTrack = function()
{
	game.context.clearRect(0,0, game.canvas.width, game.canvas.height);
    game.drawBackground();

    for(var i = 1; i < 5; i++)
    {
        game.drawFinishLine( i * 10 );        
    }

    game.drawRedStrips(0);
    game.drawRedStrips(game.canvas.height - 10);
};

Game.prototype.drawBackground = function()
{
    game.context.fillStyle = "grey";
    game.context.fillRect( 0, 0, game.canvas.width, game.canvas.height);    
};

Game.prototype.drawRedStrips = function(y)
{
    for(var i = 0; i < 100; i++)
    {
        if( i % 2 == 0 )
        {
            game.context.fillStyle = "red";
        }
        else
        {
            game.context.fillStyle = "white";
        }

        game.context.fillRect(i * 10, y,  10, 10);
    }
};

Game.prototype.drawFinishLine = function(offset)
{
    for(var i = 0; i < 80; i+=2 )
    {
        game.context.fillStyle = "white";
        if( (offset / 10) % 2 == 0 )
        {
            game.context.fillRect(game.canvas.width - offset, i * 10, 10, 10);
        }
        else
        {
            game.context.fillRect(game.canvas.width - offset, i * 10 + 10, 10, 10);
        }
         
    }
};

Game.prototype.drawCars = function()
{
  	for(var i = 0; i < game.track.length; i++)
  	{
  		game.track[i].Draw();
  	}
};