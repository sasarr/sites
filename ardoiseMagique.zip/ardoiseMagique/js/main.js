"use strict";

var slate;
var pen;
var colorPicker;

function Slate()
{
	this.canvas;
	this.context;
}

Slate.prototype.Initialize = function()
{
	this.canvas  = document.getElementById("slate");
	this.context = this.canvas.getContext("2d");
};

function Pen()
{
	this.position = 
	{
		x: 0,
		y: 0
	};

	this.size  = 5;
	this.color = "black";
	this.isDrawing = false;

	this.brush = false;
	this.star = new Image();
	this.star.src = "star.png";
}

Pen.prototype.Draw = function()
{
	if(this.brush == false)
	{
		slate.context.fillStyle = this.color;
		slate.context.fillRect(this.position.x, this.position.y, this.size, this.size);	
	}
	else
	{
		slate.context.drawImage(this.star, this.position.x, this.position.y, this.size * 3, this.size * 3);
	}
	
};


function ColorPicker()
{
	this.canvas;
	this.context;
}

ColorPicker.prototype.Initialize = function()
{
	this.canvas = document.getElementById("color-palette");
	this.context = this.canvas.getContext("2d");

	 var gradient = this.context.createLinearGradient(0, 0, this.canvas.width, 0);
	  // Create color gradient
	  gradient.addColorStop(0,    "rgb(255,   0,   0)");
	  gradient.addColorStop(0.15, "rgb(255,   0, 255)");
	  gradient.addColorStop(0.33, "rgb(0,     0, 255)");
	  gradient.addColorStop(0.49, "rgb(0,   255, 255)");
	  gradient.addColorStop(0.67, "rgb(0,   255,   0)");
	  gradient.addColorStop(0.84, "rgb(255, 255,   0)");
	  gradient.addColorStop(1,    "rgb(255,   0,   0)");
	  // Apply gradient to canvas
	  colorPicker.context.fillStyle = gradient;
	  colorPicker.context.fillRect(0, 0, colorPicker.canvas.width, colorPicker.canvas.height);
	  
	  // Create semi transparent gradient (white -> trans. -> black)
	  gradient = colorPicker.context.createLinearGradient(0, 0, 0, this.canvas.height);
	  gradient.addColorStop(0,   "rgba(255, 255, 255, 1)");
	  gradient.addColorStop(0.5, "rgba(255, 255, 255, 0)");
	  gradient.addColorStop(0.5, "rgba(0,     0,   0, 0)");
	  gradient.addColorStop(1,   "rgba(0,     0,   0, 1)");
	  // Apply gradient to canvas
	  colorPicker.context.fillStyle = gradient;
	  colorPicker.context.fillRect(0, 0, colorPicker.canvas.width, colorPicker.canvas.height);
}


window.addEventListener("DOMContentLoaded", function()
{
	slate = new Slate();
	pen   = new Pen();
	colorPicker = new ColorPicker();

	slate.Initialize();
	colorPicker.Initialize();
    //------------------------------------------------------------
    // crayon
	slate.canvas.addEventListener("mousedown", function()
	{
		pen.isDrawing = true;
	});

	slate.canvas.addEventListener("mousemove", function(event)
	{
		pen.position.x = event.clientX - slate.canvas.offsetLeft;
		pen.position.y = event.clientY - slate.canvas.offsetTop;

		if(pen.isDrawing)
		{
			pen.Draw();
		}
	});

	slate.canvas.addEventListener("mouseup", function()
	{
		pen.isDrawing = false;
	});

	//------------------------------------------------------------
	// pastilles
	var pastille = document.querySelectorAll(".pen-color");
	for(var i = 0; i < pastille.length; i++)
	{
		pastille[i].addEventListener("mousedown",function()
		{
			pen.color = this.dataset.color;
		});
	}

	//----------------------------------------------------------------
	// largeur du crayon

	var sizes = document.querySelectorAll(".pen-size");
	for(var i = 0; i < sizes.length;i++)
	{
		sizes[i].addEventListener("mousedown", function()
		{
			pen.size = this.dataset.size;
		});
	}

	//----------------------------------------------------------------
	// gomme
	document.getElementById("tool-clear-canvas").addEventListener("mousedown", function()
	{
		slate.context.clearRect(0,0, slate.canvas.width, slate.canvas.height);
	});

	//--------------------------------------------------------------------
	// color picker

	document.getElementById("tool-color-picker").addEventListener("click", function()
	{ 
		colorPalette.canvas.classList.toggle("hide");
	});


	colorPicker.canvas.addEventListener("mousedown", function(event)
	{
		var x = event.pageX - colorPicker.canvas.offsetLeft;
		var y = event.pageY - colorPicker.canvas.offsetTop;

		var pixelColor = colorPicker.context.getImageData(x,y, 1,1);
		console.log(pixelColor);
		pen.color = "rgb(" + pixelColor.data[0] + ", " + pixelColor.data[1] + ", " + pixelColor.data[2] + ")";

		console.log(pen.color);
	});
});