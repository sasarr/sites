var app;

window.addEventListener("DOMContentLoaded", function()
{
	app = new Application();
	app.cart = new Cart();
	app.carts = [];
});

class Application 
{
	constructor() 
	{
		this.articlesInStock = [];
		this.cart = null;

		for(var i = 0; i < Math.random() * 10 |0; i++)
		{
			this.articlesInStock.push( new Article(Math.random() * 100 |0, "article numero: " + i, parseFloat((Math.random() * 1000).toFixed(2)) ));
		}	
	}

	/*
		Niveau 3: 

	    Vous pourrez stocker un panier dans un compte utilisateur ( un objet également ). 
    	Si l'utilisateur ne veux pas payer son panier tout de suite, il peut l'enregistrer 
    	dans une liste d'envie de son compte utilisateur et commencer un nouveau panier.

    	Il pourra par contre récupérer sa liste d'envie en tant que panier principal de son compte.

	*/
	StockCart()
	{
		this.carts.push(this.cart);
		this.cart = null;
	}

	RetrieveCart(idOfCart)
	{
		this.cart = this.carts[idOfCart];
		this.carts.splice(idOfCart, 1);
	}
}

class Article
{
	/*
		Niveau 1: 

    	Créer un constructeur d'articles, 
    	ces articles vont pouvoir être créés
    	à partir de random, il devront avoir 
    	une quantité, un nom, un prix, la 
    	possibilité d'étre acheté seulement 
    	s'il reste des quantités supérieures 
    	à zéro
	*/
	constructor(quantity, name, price)
	{
		this.quantity = quantity;
		this.name = name;
		this.price = price;
	}

	Buy(quantityToBuy)
	{
		if(this.quantity >= quantityToBuy)
		{
			this.quantity -= quantityToBuy;

			return { 
						message: "la vente s'est bien passée",
						price: parseFloat(this.quantity + quantityToBuy * this.price.toFixed(2)), 
						remainingInStock: this.quantity 
				   };
		}
		else
		{
			return { message: "attend la prochaine livraison il n'y en a pas assez" };
		}
	}
}

class Cart
{
	/*
	Niveau 2:

    Vous allez créer un panier, ce panier sera composé d'articles. 
    Vous pouvez demander au panier de vous donner la quantité totale d'articles.

    Vous pouvez demander au panier combien tout ça va couter.
    Vous pouvez annuler un produit de votre panier
    */
	constructor()
	{
		this.articles = [];
		let randomNumberOfArticle = 1 + Math.random() * app.articlesInStock.length - 1 |0;

		for(var i = 0; i < randomNumberOfArticle; i++)
		{
			let article = app.articlesInStock[i];
			let randomQuantity = Math.random() * article.quantity |0; 

			this.articles.push({
									name: article.name, 
									quantity: randomQuantity, 
									price: article.price
									});
		}
	}

	GetNumberOfArticle()
	{
		let numberOfArticle = 0;
		for(let i = 0; i < this.articles.length; i++)
		{
			numberOfArticle += this.articles[i].quantity;
		}

		return "the number of article in the cart is: " + numberOfArticle;
	}

	GetPrice()
	{
		let finalPrice = 0;
		for(let i = 0; i < this.articles.length; i++)
		{
			finalPrice += this.articles[i].price * this.articles[i].quantity;
		}
		return "the final price of the cart is: " + finalPrice;
	}

	DeleteArticle(articleToDelete)
	{
		let article = this.articles.find( article => article.name === articleToDelete);
		this.articles.splice(this.articles.indexOf(article), 1);	
	}
}